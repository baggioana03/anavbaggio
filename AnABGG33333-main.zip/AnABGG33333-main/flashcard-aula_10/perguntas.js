criaCartao(
    'Estudos',
    '',
    'Estudo no Colégio Morski'
)

criaCartao(
    'Escola',
    '',
    'A minha sala de aula é muito legal, tenho muitos amigos'
)

criaCartao(
    'Quem sou eu?',
    '',
    'Me chamo Ana Vitória tenho 16 anos e estou no segundo ano do Ensino Médio'
)

criaCartao(
    'Família',
    '',
    'A minha família é composta por eu, meus pais, 2 tias, minha avó meu irmão e minha irmã'
)

criaCartao(
    'Faculdade',
    '',
    'Tenho interesse em fazer fisioterapia e trabalhar em uma clínica'
)

criaCartao(
    'Meu sonho',
    '',
    'Meu sonho é me formar na faculdade, realizar meus objetivos. Montar uma família e ser muito feliz'
)

criaCartao(
    'Minha cidade',
    '',
    'Minha cidade é pequena e não tem muitos recursos, é preciso viajar para outra cidade para consultar'
)

criaCartao(
    'Onde moro',
    '',
    'Moro no bairro Baggio 1, na cidade de Pinhão no interior do Paraná'
)